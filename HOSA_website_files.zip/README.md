# HOSA Website Starter

HOSA — Humanitarian Organization for Sustainability and Advancement.

## Files
- `index.html`: website structure and content
- `styles.css`: design, colors and mobile layout
- `script.js`: language switcher, mobile navigation and demo contact form
- `README.md`: this guide

## Preview
1. Extract the ZIP.
2. Open the folder.
3. Double-click `index.html`.

## Publish free with GitHub Pages
1. Open your `hosa-website` repository.
2. Choose **Add file → Upload files**.
3. Upload `index.html`, `styles.css`, `script.js` and `README.md` from this folder.
4. Click **Commit changes**.
5. Open **Settings → Pages**.
6. Select **Deploy from a branch**, choose `main` and `/(root)`, then Save.
7. Wait for publishing. Your site address will appear in Settings → Pages.

## Important before launch
- Replace the placeholder email and location with verified details.
- Add only real, approved projects, staff information and photographs.
- The contact form is a demo and opens the visitor's email app; it does not store messages online. Replace `YOUR-OFFICIAL-EMAIL@example.org` in `script.js` with HOSA's real official email.
- GitHub Pages hosts static websites. It does not include a private database, admin dashboard or server-side processing.
- Internet access is needed for Google Fonts; fallback fonts are included.
